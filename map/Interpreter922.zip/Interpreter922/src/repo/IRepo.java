package repo;

import model.ProgState;

public interface IRepo {
    public void addProgr(ProgState progState);
}
