package util;

public interface IOutput {
    public void add();
}
