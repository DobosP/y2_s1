package controller;

public class InterpretorControl {
    public void executeOneStep(){
    }
}
